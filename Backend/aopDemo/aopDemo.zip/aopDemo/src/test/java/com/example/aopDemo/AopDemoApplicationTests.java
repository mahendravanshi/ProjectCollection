package com.example.aopDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
