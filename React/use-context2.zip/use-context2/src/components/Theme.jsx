import { useContext } from "react"
import { AuthContext } from "../AuthContext/AuthContextProvider"

export const Theme = ()=>{
    const t = useContext(AuthContext)
     
    
     return (
        <>
          <button onClick={()=>t.setTheme(!t.theme)}>Change theme</button>
          <h1 style={{color:!t.theme?"white":"black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates, repellendus!</h1>
        </>
        
     )
}


