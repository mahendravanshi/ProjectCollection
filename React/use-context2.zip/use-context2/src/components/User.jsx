import { useContext } from "react"
import { AuthContext } from "../AuthContext/AuthContextProvider"
const User = ()=>{

       const user = useContext(AuthContext);
       
       console.log(user);
    return (
        <>
            <input type="text" onChange={(e)=>user.setUser(e.target.value)} />
            <h1>{user.user}</h1>
        </>
        
    )
      
}

export default User;