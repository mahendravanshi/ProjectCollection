import { useContext, useState } from "react";
import { AuthContext } from "../AuthContext/AuthContextProvider";

export const Order = () => {
  const od = useContext(AuthContext);

//   const [addOrder, setAddOrder] = useState("");
//   const handleClick = (e) => {
//     e.preventDefault();
//     od.setOrder([...od.order, addOrder]);
//   };

const handleClick=(e)=>{
e.preventDefault();
od.setOrder([...od.order,e.target.value])
}
  return (
    <>
      <form onSubmit={handleClick}>
        <input
          type="text"
          placeholder="Enter cart item"
        />
       
        <button type="submit">Submit</button>
      </form>
      {od.order.map((el, i) => {
        return (
          <>
            <h1>{el}</h1>
          </>
        );
      })}
    </>
  );
};
