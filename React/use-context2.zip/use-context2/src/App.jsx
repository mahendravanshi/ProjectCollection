import { useContext } from "react";
import { Theme } from "./components/Theme";
import User from "./components/User";
import { AuthContext } from "./AuthContext/AuthContextProvider";
import "./index.css"
import { Order } from "./components/Order";


function App() {
  const t = useContext(AuthContext);
  
  return (
    <div className="App" style={{backgroundColor:!t.theme?"white":"black",color:!t.theme?"black":"white"}}>
        <User/>
        <Theme/>
        <Order/>
    </div>
    

  );

}


export default App;





