
import {createContext,useState} from 'react';

export const AuthContext = createContext();

const AuthContextProvider = ({children})=>{

     const [cart,setCart] = useState([]);
     const [user,setUser] = useState("User login");
     const [pData,setPData] = useState([]);
     const [logout,setLogout] = useState("Logout");
     const [order,setOrder] = useState([]);
     const [theme,setTheme] = useState(false);
     
    return(
        
        <AuthContext.Provider
           value={{cart,setCart,user,setUser,pData,setPData,logout,setLogout,order,setOrder,theme,setTheme}}
        >
           {children}
        </AuthContext.Provider>
        
        
    )

}

export default AuthContextProvider;