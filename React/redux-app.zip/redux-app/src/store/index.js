// store/index.js
import { legacy_createStore} from "react/redux"
import counterReducer from '../reducers';



const store = legacy_createStore(counterReducer);

export default store;


