// components/Counter.js
import React from 'react';
import { connect } from 'react-redux';
import {increment,decrement,reset } from '../actions';

export const Counter = ({count,increment,decrement,reset}) => {
  return (
    <div>
      <h1>Counter:{count}</h1>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement}>Decrement</button>
      <button onClick={reset}>Reset</button>
    </div>
  );
};



const mapStateToProps = (state) => {
  return {
    count: state,
  };
};



export default connect(mapStateToProps, {increment, decrement ,reset})(Counter);
