const inititalValue = {
  count:0
}

// reducers/index.js
const counterReducer = (state = inititalValue, action) => {
    switch (action.type) {
      case 'INCREMENT':
        return state + 1;
      case 'DECREMENT':
        return state - 1;
      case 'RESET': 
           return inititalValue;
      default:
        return state;
    }
  };
  
  export default counterReducer;
  