package com.springAi;

public record TopSong(String title,String artist,String album,String year){
}
