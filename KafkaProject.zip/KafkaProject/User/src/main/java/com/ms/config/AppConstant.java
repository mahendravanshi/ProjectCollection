package com.ms.config;

import org.apache.kafka.common.errors.GroupIdNotFoundException;

public class AppConstant {


	public static final String updats = "location-update";
	public static final String groupId = "group-1";

	
}
