package com.ms.config;

public class AppConstants {

	public static final String location_topic = "location-update";
}
