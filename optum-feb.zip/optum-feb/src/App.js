import './App.css';
import { Example } from './Components/Example';
import MyButton from './Components/MyButton';


function App() {
  return (
    <div className="App">
         <Example/>
         <MyButton/>
    </div>
  );
}

export default App;
